const BACKEND = "http://localhost:6969"

export { BACKEND }
