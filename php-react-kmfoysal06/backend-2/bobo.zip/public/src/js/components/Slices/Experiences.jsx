import React from 'react';


const Experiences= ({ slice }) => {
  return (
    <section
      data-slice-type={slice.slice_type}
      data-slice-variation={slice.variation}
      className="charming-portfolio-slice charming-portfolio-experiences"
    >
      <div className="charming-portfolio-container charming-portfolio-experience-section">
        <div className="section-header">
          <h2 className="badge">{slice.primary.badge}</h2>
          <p>{slice.primary.section_description}</p>
        </div>
        <div className="section-content">
          {slice.primary.experiences.map((item, key) => (
            <div className="single-experience" tabIndex={0} key={key}>
              <img 
                src={item.image.url}
                alt={item.title || 'Experience'}
              />
              <div className="experience-details">
                <div className="primary-details">
                  <h3>{item.title}</h3>
                  <p className="timerange">
                    {item.start_time
                      ? new Date(item.start_time).toLocaleString("en-US", { month: "short", year: "numeric" })
                      : "Unknown"}
                    {" - "}
                    {!item.currently_working
                      ? (item.end_time
                          ? new Date(item.end_time).toLocaleString("en-US", { month: "short", year: "numeric" })
                          : "Unknown")
                      : "Current"}
                  </p>
                </div>
                <p className="designation">{item.designation}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experiences;
